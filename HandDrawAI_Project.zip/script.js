const video=document.getElementById('video');
const canvas=document.getElementById('draw');
const ctx=canvas.getContext('2d');
function resize(){canvas.width=innerWidth;canvas.height=innerHeight;}
resize();addEventListener('resize',resize);
let last=null,erase=false;
const color=document.getElementById('color');
const size=document.getElementById('size');
document.getElementById('eraser').onclick=()=>erase=!erase;
document.getElementById('clear').onclick=()=>ctx.clearRect(0,0,canvas.width,canvas.height);
document.getElementById('save').onclick=()=>{
 const a=document.createElement('a');
 a.download='airdraw.png';a.href=canvas.toDataURL();a.click();
};
const hands=new Hands({locateFile:(f)=>`https://cdn.jsdelivr.net/npm/@mediapipe/hands/${f}`});
hands.setOptions({maxNumHands:1,modelComplexity:1,minDetectionConfidence:.7,minTrackingConfidence:.7});
hands.onResults(res=>{
 if(!res.multiHandLandmarks||!res.multiHandLandmarks.length){last=null;return;}
 const p=res.multiHandLandmarks[0][8];
 const x=(1-p.x)*canvas.width;
 const y=p.y*canvas.height;
 ctx.lineCap='round';
 ctx.lineJoin='round';
 ctx.lineWidth=size.value;
 ctx.strokeStyle=erase?'#111':color.value;
 if(last){
   ctx.beginPath();
   ctx.moveTo(last.x,last.y);
   ctx.lineTo(x,y);
   ctx.stroke();
 }
 last={x,y};
});
navigator.mediaDevices.getUserMedia({video:true}).then(stream=>{
 video.srcObject=stream;
 const cam=new Camera(video,{onFrame:async()=>{await hands.send({image:video});},width:1280,height:720});
 cam.start();
});